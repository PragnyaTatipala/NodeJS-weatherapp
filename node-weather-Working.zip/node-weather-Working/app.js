const express = require('express');
const path = require('path');
const app = express();
const iss = require('./modules/iss');

// Routes which should handle request
app.get('/',function(req,res){
    res.sendFile(path.join(__dirname+'/index.html'));
});

app.get('/is-iss-visible', function (req, res) {
    iss.isVisible(function (err, result) {
        if (err) {
            res.status(err);
            return res.sendStatus(err);
        }
        console.log("got the result of iss visibility:" + result);
        res.json(result);
    });
});

//Capture All 404 errors
app.use(function (req,res,next){
	res.status(404).send('The requested resource does not exist.');
});

//export app
module.exports = app;


