const restcall = require('./api');
const API_KEY = '8e81de416e86c8ba7163658d1f0bab54';

const issVisibiltyState = {
	YES: "yes",
	POSSIBLY: "possibly",
	NOT: "not"
};

const weatherMain = {
  CLEAR: "Clear",
  CLOUDS: "Clouds"
}

var getCurIssLatAndLong = function (callback) {
  const getIssCurLocationHost='api.open-notify.org';

  var options = {
    host: getIssCurLocationHost,
    path: '/iss-now.json',
    method: 'GET'
  };
  restcall.makeHttpRequest(options, callback);
};

var getWeatherAtIssLocation = function(lat, long, callback){
  const getWeatherHost= 'api.openweathermap.org';
  const pathWithQuery = encodeURI('/data/2.5/weather?lat='+ lat +'&lon='+ long +'&appid='+ API_KEY);

  var options = {
    host: getWeatherHost,
    path: pathWithQuery,
    method: 'GET'
  };
  restcall.makeHttpRequest(options, callback);
};

var visibility = (function () {
  return {
    isVisible: function(callback){
      var checkVisibilty = function(weatherResp){
        // if current timestamp is between sunrise and sunset of current day then iss is not visible
        if(weatherResp.sys.sunrise < weatherResp.dt && weatherResp.dt <= weatherResp.sys.sunset){
          return issVisibiltyState.NOT;
        }
        if(weatherResp.weather.main == weatherMain.CLOUDS){
          return issVisibiltyState.POSSIBLY;
        } else if(weatherResp.weather.main == weatherMain.CLEAR){
          return issVisibiltyState.YES;
        }
        // in all other cases of weather main return not visible
        return issVisibiltyState.NOT;
      };

      var buildResponse = function(resp){
        var result = {};
        // country is not defined in resp if iss is not over a country
        if (typeof resp.sys.country !== 'undefined' && resp.sys.country !== null){
          result.country = resp.sys.country;
        } else {
          result.country = '';
        }
        result.city = resp.name;
        result.lat = resp.coord.lat;
        result.long = resp.coord.lon;
        result.visibility = checkVisibilty(resp);
        callback(null, result)
      };

      var getWeatherCallback = function (err, result){
        if (err) {
          callback(err, null);
        } else {
          console.log("got the weather at iss location:" + result);
          // now that we have the data required build response accordingly
          buildResponse(result);
        }
      };

      var getLocationCallback = function (err, result) {
        console.log("here: "+err);
        if (err) {
          callback(err, null);
        } else {
          console.log("got the result of iss:" + result);
          // now that we have iss loc get the weather at that loc
          getWeatherAtIssLocation(result.iss_position.latitude, result.iss_position.longitude, getWeatherCallback);
        }
      };

      getCurIssLatAndLong(getLocationCallback);
    }
  };
}());
  
module.exports = visibility;