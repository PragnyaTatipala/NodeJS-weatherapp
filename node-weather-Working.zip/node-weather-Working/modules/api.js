const http = require('http');

var restCall = (function(){
    return {
        makeHttpRequest: function(options, callback){
            var req = http.request(options, function(response) {
                console.log('STATUS: ' + response.statusCode);
                // node js does not treat 400, 404 as erros so handling it manually
                // only processing the response if the response status is 200 OK
                if(response.statusCode != 200){
                    console.log("got err");
                    console.log(callback);
                    callback(response.statusCode, null);
                } else {
                    console.log('HEADERS: ' + JSON.stringify(response.headers));
                    response.setEncoding('utf8');
                    response.on('data', function (res) {
                        console.log('BODY: ' + res);
                        callback(null, JSON.parse(res));
                    });
                }
              });
              req.on('error', function (e) {
                console.log('ERROR: ' + e);
                callback(e.status, null)
              });
              req.on('timeout', function () {
                console.log('Request timeout');
                callback(408, null)
              });
              req.end();
        }
    };
}());

module.exports = restCall;